﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using QALab8_BiancaTuliao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QALab8_BiancaTuliao.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void CreateBoardTest()
        {
            TicTacToe game = new TicTacToe();
            int correctNum = 9;

            if (game.CreateBoard() == 9)
            {
                Assert.IsTrue((game.CreateBoard() == 9) == true);
            }

        }

        [TestMethod()]
        public void CurrentPlayerTest()
        {
            TicTacToe game = new TicTacToe();

            if (game.CurrentPlayer() == "X" || game.CurrentPlayer() == "O")
            {
                Assert.IsTrue((game.CurrentPlayer() == "X" || game.CurrentPlayer() == "O") == true);
            }
        }

        [TestMethod()]
        public void ChangePlayerTest()
        {
            TicTacToe game = new TicTacToe();

            if (game.ChangePlayer() == "X" || game.ChangePlayer() == "O")
            {
                Assert.IsTrue((game.ChangePlayer() == "X" || game.ChangePlayer() == "O") == true);
            }
        }

        [TestMethod()]
        public void MakeMoveTest()
        {
            TicTacToe game = new TicTacToe();

            int x = 2; // x location
            int y = 2; // y location

            if (game.MakeMove(x, y, game.CurrentPlayer()) == true)
            {
                Assert.IsTrue(game.MakeMove(x, y, game.CurrentPlayer()) == true);
            }
        }

        [TestMethod()]
        public void SpaceInUseTest()
        {
            TicTacToe game = new TicTacToe();

            int x = 1; // x location
            int y = 1; // y location

            if (game.SpaceInUse(x, y) == true)
            {
                Assert.IsTrue(game.SpaceInUse(x, y) == true);
            }
        }
    }
}