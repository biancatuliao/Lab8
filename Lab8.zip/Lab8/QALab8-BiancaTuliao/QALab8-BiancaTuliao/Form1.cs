﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QALab8_BiancaTuliao
{
    public partial class Form1 : Form
    {
        private static string player1 = "X"; // player 1 token
        private static string player2 = "O"; // player 2 token
        private static string currentPlayer = player1; // stores current player token
        private string[,] board; // board

        public Form1()
        {
            InitializeComponent();
        }

        // sets size of board and returns total number of spaces available on the board
        public int CreateBoard()
        {
            board = new string[3,3];
            int numOfSpaces = 0;

            for (int i = 0; i <= board.Length; i++)
            {
                for (int j = 0; j <= board.Length; j++)
                {
                    numOfSpaces++;
                }
            }

            return 9;
        }

        // returns the current player 
        public String CurrentPlayer()
        {
            return currentPlayer;
        }

        // changes current player to player specified in parameter
        public String ChangePlayer()
        {
            if (currentPlayer == "X")
            {
                currentPlayer = "O";
            }
            else if (currentPlayer == "O")
            {
                currentPlayer = "X";
            }
            else
            {
                currentPlayer = "";
            }
            
            return currentPlayer;
        }

        // places a token corresponding to the current player in the specified location on board
        // returns true if move was successful
        public Boolean MakeMove(int x, int y, string currentPlayer)
        {
            Boolean success = false;

            if (board[x, y] == "")
            {
                board[x, y] = currentPlayer;

                success = true; // for good measure
                return true;
            }

            return success;
        }

        // checks to see if the specified location on the board is empty or not
        public Boolean SpaceInUse(int x, int y)
        {
            Boolean inUse = false; 

            for (int i = 0; i <= board.Length; i++)
            {
                for (int j = 0; j <= board.Length; j++)
                {
                    if (board[x,y] != "")
                    {
                        inUse = true;
                    }
                }
            }

            return inUse;
        }
    }
}
